package com.company.abstractionEmployee;

public class CommissionEmployee extends Employee{
    private int TotalSales;
    private int Commission;




    @Override
    public   void earning(){
        System.out.println(" Commission Employee");
        CommissionEmployee commissionEmployee = new CommissionEmployee();
        commissionEmployee.setName("AAshish");
        commissionEmployee.setCommission(450);
        commissionEmployee.setTotalSales(4500);
        System.out.println(commissionEmployee.toString());

    }



    public int getTotalSales() {
        return TotalSales;
    }

    public void setTotalSales(int totalSales) {
        TotalSales = totalSales;
    }

    public int getCommission() {
        return Commission;
    }

    public void setCommission(int commission) {
        Commission = commission;
    }


    @Override
    public String toString(){
        return  super.toString() +  "  total sales " +getTotalSales() +   "commission of employee " +getCommission() ;
    }
}
