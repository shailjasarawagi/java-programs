package com.company.abstractionEmployee;

public enum EnumTypes {
        SALARYEMPLOYEE, COMISSIONEMPLOYEE, HOURLYEMPLOYEE;

    }



