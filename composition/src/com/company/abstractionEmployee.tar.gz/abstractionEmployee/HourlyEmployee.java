package com.company.abstractionEmployee;

public class HourlyEmployee extends Employee {
    private int hour;

    @Override
    public void earning() {
        System.out.println(" Hourly Employee");
        HourlyEmployee hourlyEmployee = new HourlyEmployee();
        hourlyEmployee.setName("Aashish");
        hourlyEmployee.setAddress("sanepa");
        hourlyEmployee.setSalary(3400);
        hourlyEmployee.setHour(3);
        System.out.println(hourlyEmployee.toString());

    }

    public int getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }


    @Override
    public String toString(){
        return  super.toString() +" hour of employee " +getHour() ;
    }
}

