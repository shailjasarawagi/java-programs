package com.company.abstractionEmployee;


import java.util.Scanner;

public class EmployeeMain {
    public static void main(String[] args) {
        SalaryEmployee salaryEmployee = new SalaryEmployee();
        salaryEmployee.earning();
        HourlyEmployee hourlyEmployee= new HourlyEmployee();
        hourlyEmployee.earning();
        CommissionEmployee commissionEmployee = new CommissionEmployee();
        commissionEmployee.earning();

    }
}
