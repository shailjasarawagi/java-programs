package com.company.employees;

public enum EnumTypes {
        SALARYEMPLOYEE, COMISSIONEMPLOYEE, HOURLYEMPLOYEE;
    }


